export const BASE_URL = "";
export const BACKEND_URL = "http://localhost:5000/";
export const USERS_URL = "http://localhost:5000/api/users";
