export const BASE_URL = "";
export const BACKEND_URL = "https://palmoild-sand.vercel.app/";
export const USERS_URL = "https://palmoild-sand.vercel.app/api/users";
